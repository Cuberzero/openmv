Thank you for supporting the OpenMV project!

To download the IDE, please visit:
https://openmv.io/pages/download

For tutorials and documentation, please visit:
http://docs.openmv.io/

For technical support and projects, please visit the forums:
http://forums.openmv.io/

Please use github to report bugs and issues:
https://github.com/openmv/openmv
